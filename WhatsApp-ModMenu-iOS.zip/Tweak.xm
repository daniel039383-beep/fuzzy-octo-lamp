#import <UIKit/UIKit.h>
#import <objc/runtime.h>

// Estructura para definir cada parche en la lista
@interface PatchItem : NSObject
@property (nonatomic, strong) NSString *key;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *subtitle;
@end

@implementation PatchItem
+ (instancetype)itemWithKey:(NSString *)key title:(NSString *)title subtitle:(NSString *)subtitle {
    PatchItem *item = [[PatchItem alloc] init];
    item.key = key;
    item.title = title;
    item.subtitle = subtitle;
    return item;
}
@end

// Controlador del Menu de Parches (Modal)
@interface ParchesMenuViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray<PatchItem *> *patches;
@end

@implementation ParchesMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Parches";
    self.view.backgroundColor = [UIColor colorWithRed:0.11 green:0.11 blue:0.12 alpha:1.0];

    // Configurar barra de navegacion estilo iOS oscuro
    UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
    [appearance configureWithOpaqueBackground];
    appearance.backgroundColor = [UIColor colorWithRed:0.15 green:0.15 blue:0.16 alpha:1.0];
    appearance.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    self.navigationController.navigationBar.standardAppearance = appearance;
    self.navigationController.navigationBar.scrollEdgeAppearance = appearance;

    // Boton "Cerrar" arriba a la izquierda
    UIBarButtonItem *closeBtn = [[UIBarButtonItem alloc] initWithTitle:@"Cerrar"
                                                                 style:UIBarButtonItemStylePlain
                                                                target:self
                                                                action:@selector(closeMenu)];
    closeBtn.tintColor = [UIColor systemBlueColor];
    self.navigationItem.leftBarButtonItem = closeBtn;

    // Lista de parches
    self.patches = @[
        [PatchItem itemWithKey:@"patch_meta_floating"
                         title:@"-[WAChatListViewController chatListNavigationMetaAIFloatingButtonEnabled]"
                      subtitle:@"[WAChatListViewController chatListNavigationMetaAIFloatingButtonEnabled] -> NO"],
        [PatchItem itemWithKey:@"patch_meta_context"
                         title:@"-[WAMessageContextMenuActionsControl canAskMetaAI]"
                      subtitle:@"[WAMessageContextMenuActionsControl canAskMetaAI] -> NO"],
        [PatchItem itemWithKey:@"patch_meta_private"
                         title:@"-[WAMessageContextMenuActionsControl canAskMetaAIPrivately]"
                      subtitle:@"[WAMessageContextMenuActionsControl canAskMetaAIPrivately] -> NO"],
        [PatchItem itemWithKey:@"patch_meta_groups"
                         title:@"-[WAGroupsBotSelectionManager shouldShowMetaAISection]"
                      subtitle:@"[WAGroupsBotSelectionManager shouldShowMetaAISection] -> NO"],
        [PatchItem itemWithKey:@"patch_meta_search"
                         title:@"-[WASearchBarViewController showMetaAIPrompts]"
                      subtitle:@"[WASearchBarViewController showMetaAIPrompts] -> NO"]
    ];

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorColor = [UIColor colorWithWhite:0.25 alpha:1.0];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.tableView];
}

- (void)closeMenu {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.patches.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 105.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"PatchCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.textLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
        cell.textLabel.numberOfLines = 3;

        cell.detailTextLabel.textColor = [UIColor lightGrayColor];
        cell.detailTextLabel.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
        cell.detailTextLabel.numberOfLines = 3;
    }

    PatchItem *item = self.patches[indexPath.row];
    cell.textLabel.text = item.title;
    cell.detailTextLabel.text = item.subtitle;

    UISwitch *toggle = [[UISwitch alloc] init];
    toggle.onTintColor = [UIColor systemGreenColor];
    toggle.tag = indexPath.row;
    toggle.on = [[NSUserDefaults standardUserDefaults] boolForKey:item.key];
    [toggle addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    cell.accessoryView = toggle;

    return cell;
}

- (void)switchChanged:(UISwitch *)sender {
    PatchItem *item = self.patches[sender.tag];
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:item.key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end

// Boton Flotante Arrastrable
@interface FloatingMenuButton : UIButton
@end

@implementation FloatingMenuButton

+ (void)setupFloatingButton {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            UIWindow *keyWindow = nil;
            for (UIWindowScene *scene in [UIApplication sharedApplication].connectedScenes) {
                if (scene.activationState == UISceneActivationStateForegroundActive) {
                    for (UIWindow *w in scene.windows) {
                        if (w.isKeyWindow) {
                            keyWindow = w;
                            break;
                        }
                    }
                }
            }
            if (!keyWindow) return;

            FloatingMenuButton *btn = [FloatingMenuButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(20, 450, 46, 46);
            btn.backgroundColor = [UIColor colorWithRed:0.15 green:0.0 blue:0.0 alpha:0.85];
            btn.layer.cornerRadius = 23;
            btn.layer.borderWidth = 2.0;
            btn.layer.borderColor = [UIColor systemRedColor].CGColor;
            btn.layer.shadowColor = [UIColor systemRedColor].CGColor;
            btn.layer.shadowRadius = 8.0;
            btn.layer.shadowOpacity = 0.9;
            btn.layer.shadowOffset = CGSizeZero;
            
            [btn setTitle:@"⚙︎" forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor systemRedColor] forState:UIControlStateNormal];
            btn.titleLabel.font = [UIFont systemFontOfSize:24 weight:UIFontWeightBold];

            [btn addTarget:btn action:@selector(openPatchesMenu) forControlEvents:UIControlEventTouchUpInside];
            
            UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:btn action:@selector(handlePan:)];
            [btn addGestureRecognizer:pan];

            [keyWindow addSubview:btn];
        });
    });
}

- (void)handlePan:(UIPanGestureRecognizer *)pan {
    CGPoint translation = [pan translationInView:self.superview];
    self.center = CGPointMake(self.center.x + translation.x, self.center.y + translation.y);
    [pan setTranslation:CGPointZero inView:self.superview];
}

- (void)openPatchesMenu {
    ParchesMenuViewController *menuVC = [[ParchesMenuViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:menuVC];
    nav.modalPresentationStyle = UIModalPresentationPageSheet;

    UIViewController *rootVC = self.window.rootViewController;
    while (rootVC.presentedViewController) {
        rootVC = rootVC.presentedViewController;
    }
    [rootVC presentViewController:nav animated:YES completion:nil];
}

@end

// ==========================================
// HOOKS DE WHATSAPP (LOGOS)
// ==========================================

static BOOL isPatchEnabled(NSString *key) {
    return [[NSUserDefaults standardUserDefaults] boolForKey:key];
}

%hook WAChatListViewController

- (void)viewDidAppear:(BOOL)animated {
    %orig;
    [FloatingMenuButton setupFloatingButton];
}

- (BOOL)chatListNavigationMetaAIFloatingButtonEnabled {
    if (isPatchEnabled(@"patch_meta_floating")) {
        return NO;
    }
    return %orig;
}

%end

%hook WAMessageContextMenuActionsControl

- (BOOL)canAskMetaAI {
    if (isPatchEnabled(@"patch_meta_context")) {
        return NO;
    }
    return %orig;
}

- (BOOL)canAskMetaAIPrivately {
    if (isPatchEnabled(@"patch_meta_private")) {
        return NO;
    }
    return %orig;
}

%end

%hook WAGroupsBotSelectionManager

- (BOOL)shouldShowMetaAISection {
    if (isPatchEnabled(@"patch_meta_groups")) {
        return NO;
    }
    return %orig;
}

%end
